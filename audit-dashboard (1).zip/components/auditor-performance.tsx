"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "@/components/ui/chart"

// Mock data for auditor performance
const auditorData = [
  {
    name: "John D.",
    findings: 28,
    reports: 5,
  },
  {
    name: "Sarah M.",
    findings: 32,
    reports: 6,
  },
  {
    name: "Robert K.",
    findings: 19,
    reports: 4,
  },
  {
    name: "Lisa T.",
    findings: 24,
    reports: 5,
  },
  {
    name: "Michael P.",
    findings: 15,
    reports: 3,
  },
]

export function AuditorPerformance() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Auditor Performance</CardTitle>
        <CardDescription>Findings and reports by auditor</CardDescription>
      </CardHeader>
      <CardContent className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={auditorData}
            margin={{
              top: 20,
              right: 30,
              left: 0,
              bottom: 5,
            }}
            layout="vertical"
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis type="number" />
            <YAxis dataKey="name" type="category" width={80} />
            <Tooltip />
            <Legend />
            <Bar dataKey="findings" fill="#8b5cf6" name="Findings" />
            <Bar dataKey="reports" fill="#0ea5e9" name="Reports" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
