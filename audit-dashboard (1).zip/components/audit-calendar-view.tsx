"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ChevronLeft, ChevronRight, CalendarIcon, List, Grid3X3 } from "lucide-react"

// Mock data for audit dates
const auditEvents = [
  {
    id: 1,
    title: "Financial Controls Audit",
    date: new Date(2025, 4, 5),
    endDate: new Date(2025, 4, 10),
    department: "Finance",
    type: "Financial",
    auditors: ["John Doe", "Sarah Miller"],
    status: "Scheduled",
  },
  {
    id: 2,
    title: "IT Security Assessment",
    date: new Date(2025, 4, 12),
    endDate: new Date(2025, 4, 18),
    department: "IT",
    type: "IT",
    auditors: ["Robert Kim", "Lisa Thompson"],
    status: "Scheduled",
  },
  {
    id: 3,
    title: "HR Policy Compliance Review",
    date: new Date(2025, 4, 15),
    endDate: new Date(2025, 4, 20),
    department: "HR",
    type: "Compliance",
    auditors: ["Michael Park"],
    status: "In Progress",
  },
  {
    id: 4,
    title: "Supply Chain Process Audit",
    date: new Date(2025, 4, 20),
    endDate: new Date(2025, 4, 25),
    department: "Operations",
    type: "Operational",
    auditors: ["John Doe", "Lisa Thompson"],
    status: "Scheduled",
  },
  {
    id: 5,
    title: "Treasury Management Review",
    date: new Date(2025, 4, 25),
    endDate: new Date(2025, 4, 30),
    department: "Finance",
    type: "Financial",
    auditors: ["Sarah Miller"],
    status: "Scheduled",
  },
  {
    id: 6,
    title: "Data Privacy Compliance Audit",
    date: new Date(2025, 5, 2),
    endDate: new Date(2025, 5, 8),
    department: "Legal",
    type: "Compliance",
    auditors: ["Robert Kim", "Michael Park"],
    status: "Scheduled",
  },
  {
    id: 7,
    title: "Network Infrastructure Review",
    date: new Date(2025, 5, 10),
    endDate: new Date(2025, 5, 15),
    department: "IT",
    type: "IT",
    auditors: ["Lisa Thompson"],
    status: "Scheduled",
  },
]

export function AuditCalendarView() {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [view, setView] = useState<"month" | "list">("month")

  // Find audits for the selected date
  const selectedDateAudits = auditEvents.filter(
    (audit) =>
      date &&
      ((date.getDate() >= new Date(audit.date).getDate() &&
        date.getDate() <= new Date(audit.endDate).getDate() &&
        date.getMonth() === new Date(audit.date).getMonth() &&
        date.getFullYear() === new Date(audit.date).getFullYear()) ||
        (date.getDate() >= new Date(audit.date).getDate() &&
          date.getMonth() === new Date(audit.date).getMonth() &&
          date.getFullYear() === new Date(audit.date).getFullYear() &&
          date.getMonth() === new Date(audit.endDate).getMonth()) ||
        (date.getDate() <= new Date(audit.endDate).getDate() &&
          date.getMonth() === new Date(audit.endDate).getMonth() &&
          date.getFullYear() === new Date(audit.endDate).getFullYear() &&
          date.getMonth() === new Date(audit.date).getMonth())),
  )

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "in progress":
        return "default"
      case "scheduled":
        return "secondary"
      case "completed":
        return "outline"
      default:
        return "outline"
    }
  }

  const getTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case "financial":
        return "default"
      case "compliance":
        return "secondary"
      case "it":
        return "destructive"
      case "operational":
        return "outline"
      default:
        return "outline"
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => setDate(new Date())}>
            <CalendarIcon className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => setView("month")}>
            <Grid3X3 className="mr-2 h-4 w-4" />
            Month
          </Button>
          <Button variant="outline" size="sm" onClick={() => setView("list")}>
            <List className="mr-2 h-4 w-4" />
            List
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {view === "month" ? (
        <div className="grid gap-4 md:grid-cols-7">
          <Card className="md:col-span-5">
            <CardContent className="p-4">
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                className="rounded-md border"
                modifiers={{
                  audit: auditEvents.flatMap((a) => {
                    const dates = []
                    const start = new Date(a.date)
                    const end = new Date(a.endDate)
                    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
                      dates.push(new Date(d))
                    }
                    return dates
                  }),
                }}
                modifiersStyles={{
                  audit: {
                    fontWeight: "bold",
                    backgroundColor: "hsl(var(--primary) / 0.1)",
                    color: "hsl(var(--primary))",
                  },
                }}
              />
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardContent className="p-4">
              <h3 className="font-medium mb-4">
                {date
                  ? date.toLocaleDateString("en-US", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })
                  : "Select a date"}
              </h3>

              {selectedDateAudits.length > 0 ? (
                <div className="space-y-4">
                  {selectedDateAudits.map((audit) => (
                    <div key={audit.id} className="rounded-lg border p-3">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">{audit.title}</h4>
                        <Badge variant={getTypeColor(audit.type) as any}>{audit.type}</Badge>
                      </div>
                      <div className="mt-2 text-sm text-muted-foreground">
                        <p>Department: {audit.department}</p>
                        <p>
                          {new Date(audit.date).toLocaleDateString()} - {new Date(audit.endDate).toLocaleDateString()}
                        </p>
                        <p>Auditors: {audit.auditors.join(", ")}</p>
                      </div>
                      <div className="mt-2 flex items-center justify-between">
                        <Badge variant={getStatusColor(audit.status) as any}>{audit.status}</Badge>
                        <Button variant="ghost" size="sm">
                          View Details
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">No audits scheduled for this date.</p>
              )}
            </CardContent>
          </Card>
        </div>
      ) : (
        <Card>
          <CardContent className="p-4">
            <Tabs defaultValue="upcoming">
              <TabsList>
                <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                <TabsTrigger value="in-progress">In Progress</TabsTrigger>
                <TabsTrigger value="completed">Completed</TabsTrigger>
                <TabsTrigger value="all">All</TabsTrigger>
              </TabsList>

              <TabsContent value="upcoming" className="mt-4">
                <div className="space-y-4">
                  {auditEvents
                    .filter((audit) => audit.status === "Scheduled")
                    .map((audit) => (
                      <div key={audit.id} className="flex items-start justify-between rounded-lg border p-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium">{audit.title}</h4>
                            <Badge variant={getTypeColor(audit.type) as any}>{audit.type}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">Department: {audit.department}</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(audit.date).toLocaleDateString()} - {new Date(audit.endDate).toLocaleDateString()}
                          </p>
                          <p className="text-sm text-muted-foreground">Auditors: {audit.auditors.join(", ")}</p>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <Badge variant={getStatusColor(audit.status) as any}>{audit.status}</Badge>
                          <Button variant="outline" size="sm">
                            View Details
                          </Button>
                        </div>
                      </div>
                    ))}
                </div>
              </TabsContent>

              <TabsContent value="in-progress" className="mt-4">
                <div className="space-y-4">
                  {auditEvents
                    .filter((audit) => audit.status === "In Progress")
                    .map((audit) => (
                      <div key={audit.id} className="flex items-start justify-between rounded-lg border p-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium">{audit.title}</h4>
                            <Badge variant={getTypeColor(audit.type) as any}>{audit.type}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">Department: {audit.department}</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(audit.date).toLocaleDateString()} - {new Date(audit.endDate).toLocaleDateString()}
                          </p>
                          <p className="text-sm text-muted-foreground">Auditors: {audit.auditors.join(", ")}</p>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <Badge variant={getStatusColor(audit.status) as any}>{audit.status}</Badge>
                          <Button variant="outline" size="sm">
                            View Details
                          </Button>
                        </div>
                      </div>
                    ))}
                </div>
              </TabsContent>

              <TabsContent value="completed" className="mt-4">
                <p className="text-muted-foreground">No completed audits to display.</p>
              </TabsContent>

              <TabsContent value="all" className="mt-4">
                <div className="space-y-4">
                  {auditEvents.map((audit) => (
                    <div key={audit.id} className="flex items-start justify-between rounded-lg border p-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium">{audit.title}</h4>
                          <Badge variant={getTypeColor(audit.type) as any}>{audit.type}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">Department: {audit.department}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(audit.date).toLocaleDateString()} - {new Date(audit.endDate).toLocaleDateString()}
                        </p>
                        <p className="text-sm text-muted-foreground">Auditors: {audit.auditors.join(", ")}</p>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge variant={getStatusColor(audit.status) as any}>{audit.status}</Badge>
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
