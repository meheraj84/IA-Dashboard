import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { FileText, AlertTriangle, CheckCircle, Clock } from "lucide-react"

// Mock data for recent activity
const activities = [
  {
    id: 1,
    user: {
      name: "John Doe",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "JD",
    },
    action: "published a new report",
    target: "Q1 Financial Audit",
    time: "2 hours ago",
    icon: FileText,
  },
  {
    id: 2,
    user: {
      name: "Sarah Miller",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "SM",
    },
    action: "added a new finding",
    target: "IT Security Controls",
    time: "4 hours ago",
    icon: AlertTriangle,
  },
  {
    id: 3,
    user: {
      name: "Robert Kim",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "RK",
    },
    action: "completed corrective action",
    target: "HR Policy Compliance",
    time: "Yesterday",
    icon: CheckCircle,
  },
  {
    id: 4,
    user: {
      name: "Lisa Thompson",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "LT",
    },
    action: "scheduled a new audit",
    target: "Operations Process Review",
    time: "Yesterday",
    icon: Clock,
  },
]

export function RecentActivity() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
        <CardDescription>Latest actions in the audit system</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-start gap-4">
              <Avatar className="h-9 w-9">
                <AvatarImage src={activity.user.avatar || "/placeholder.svg"} alt={activity.user.name} />
                <AvatarFallback>{activity.user.initials}</AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-1">
                <p className="text-sm font-medium leading-none">
                  {activity.user.name} {activity.action}
                </p>
                <div className="flex items-center text-sm text-muted-foreground">
                  <activity.icon className="mr-1 h-3 w-3" />
                  <span>{activity.target}</span>
                </div>
                <p className="text-xs text-muted-foreground">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
