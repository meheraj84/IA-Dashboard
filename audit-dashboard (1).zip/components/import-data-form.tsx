"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function ImportDataForm() {
  const [file, setFile] = useState<File | null>(null)
  const [importType, setImportType] = useState("findings")
  const [isUploading, setIsUploading] = useState(false)
  const [uploadSuccess, setUploadSuccess] = useState(false)
  const { toast } = useToast()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0])
      setUploadSuccess(false)
    }
  }

  const handleImport = () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please select a file to import",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)

    // Simulate file upload
    setTimeout(() => {
      setIsUploading(false)
      setUploadSuccess(true)
      toast({
        title: "Import successful",
        description: `${file.name} has been imported successfully.`,
      })
    }, 2000)
  }

  return (
    <Card className="max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle>Import Data</CardTitle>
        <CardDescription>Upload Excel files to import data into the audit system</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Tabs defaultValue="file-upload" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="file-upload">File Upload</TabsTrigger>
            <TabsTrigger value="template">Download Templates</TabsTrigger>
          </TabsList>
          <TabsContent value="file-upload" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="import-type">Import Type</Label>
              <Select value={importType} onValueChange={setImportType}>
                <SelectTrigger id="import-type">
                  <SelectValue placeholder="Select import type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="findings">Audit Findings</SelectItem>
                  <SelectItem value="reports">Audit Reports</SelectItem>
                  <SelectItem value="schedule">Audit Schedule</SelectItem>
                  <SelectItem value="corrective-actions">Corrective Actions</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="file-upload">Upload File</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="file-upload"
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  onChange={handleFileChange}
                  className="flex-1"
                />
                <Button variant="outline" size="icon" onClick={() => document.getElementById("file-upload")?.click()}>
                  <Upload className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">Accepted formats: .xlsx, .xls, .csv</p>
            </div>

            {file && (
              <div className="flex items-center gap-2 text-sm">
                <FileSpreadsheet className="h-4 w-4 text-muted-foreground" />
                <span>{file.name}</span>
                <span className="text-xs text-muted-foreground">({(file.size / 1024).toFixed(2)} KB)</span>
              </div>
            )}

            {uploadSuccess && (
              <Alert
                variant="success"
                className="bg-emerald-50 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300"
              >
                <CheckCircle className="h-4 w-4" />
                <AlertTitle>Import Successful</AlertTitle>
                <AlertDescription>Your data has been successfully imported into the system.</AlertDescription>
              </Alert>
            )}
          </TabsContent>
          <TabsContent value="template" className="space-y-4">
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Download Templates</AlertTitle>
              <AlertDescription>
                Download the appropriate template for your data import. Using the correct template ensures your data is
                imported correctly.
              </AlertDescription>
            </Alert>

            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Audit Findings Template</CardTitle>
                </CardHeader>
                <CardFooter>
                  <Button variant="outline" className="w-full" size="sm">
                    <FileSpreadsheet className="mr-2 h-4 w-4" />
                    Download Template
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Audit Reports Template</CardTitle>
                </CardHeader>
                <CardFooter>
                  <Button variant="outline" className="w-full" size="sm">
                    <FileSpreadsheet className="mr-2 h-4 w-4" />
                    Download Template
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Audit Schedule Template</CardTitle>
                </CardHeader>
                <CardFooter>
                  <Button variant="outline" className="w-full" size="sm">
                    <FileSpreadsheet className="mr-2 h-4 w-4" />
                    Download Template
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Corrective Actions Template</CardTitle>
                </CardHeader>
                <CardFooter>
                  <Button variant="outline" className="w-full" size="sm">
                    <FileSpreadsheet className="mr-2 h-4 w-4" />
                    Download Template
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter>
        <Button onClick={handleImport} disabled={!file || isUploading} className="w-full">
          {isUploading ? "Importing..." : "Import Data"}
        </Button>
      </CardFooter>
    </Card>
  )
}
