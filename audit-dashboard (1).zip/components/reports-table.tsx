"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { MoreHorizontal, Download, Edit, Trash, Eye } from "lucide-react"

// Mock data for reports
const reports = [
  {
    id: "R-2025-001",
    title: "Q1 Financial Audit Report",
    type: "Financial",
    department: "Finance",
    status: "Published",
    dateCreated: "2025-04-05",
    datePublished: "2025-04-15",
    author: "John Doe",
    findings: 12,
  },
  {
    id: "R-2025-002",
    title: "IT Security Controls Assessment",
    type: "IT",
    department: "Technology",
    status: "In Review",
    dateCreated: "2025-04-08",
    datePublished: null,
    author: "Sarah Miller",
    findings: 8,
  },
  {
    id: "R-2025-003",
    title: "HR Policy Compliance Review",
    type: "Compliance",
    department: "HR",
    status: "Draft",
    dateCreated: "2025-04-10",
    datePublished: null,
    author: "Robert Kim",
    findings: 5,
  },
  {
    id: "R-2025-004",
    title: "Supply Chain Process Audit",
    type: "Operational",
    department: "Operations",
    status: "Published",
    dateCreated: "2025-03-20",
    datePublished: "2025-04-01",
    author: "Lisa Thompson",
    findings: 15,
  },
  {
    id: "R-2025-005",
    title: "Data Privacy Compliance Audit",
    type: "Compliance",
    department: "Legal",
    status: "In Review",
    dateCreated: "2025-04-12",
    datePublished: null,
    author: "Michael Park",
    findings: 7,
  },
  {
    id: "R-2025-006",
    title: "Treasury Management Review",
    type: "Financial",
    department: "Finance",
    status: "Draft",
    dateCreated: "2025-04-18",
    datePublished: null,
    author: "John Doe",
    findings: 3,
  },
  {
    id: "R-2025-007",
    title: "Business Continuity Plan Assessment",
    type: "IT",
    department: "Technology",
    status: "Published",
    dateCreated: "2025-03-15",
    datePublished: "2025-03-30",
    author: "Sarah Miller",
    findings: 9,
  },
]

export function ReportsTable() {
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "published":
        return "secondary"
      case "in review":
        return "default"
      case "draft":
        return "outline"
      default:
        return "outline"
    }
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[100px]">ID</TableHead>
            <TableHead>Report Title</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Department</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Date Created</TableHead>
            <TableHead>Date Published</TableHead>
            <TableHead>Author</TableHead>
            <TableHead>Findings</TableHead>
            <TableHead className="w-[70px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {reports.map((report) => (
            <TableRow key={report.id}>
              <TableCell className="font-medium">{report.id}</TableCell>
              <TableCell>{report.title}</TableCell>
              <TableCell>{report.type}</TableCell>
              <TableCell>{report.department}</TableCell>
              <TableCell>
                <Badge variant={getStatusColor(report.status) as any}>{report.status}</Badge>
              </TableCell>
              <TableCell>{new Date(report.dateCreated).toLocaleDateString()}</TableCell>
              <TableCell>{report.datePublished ? new Date(report.datePublished).toLocaleDateString() : "-"}</TableCell>
              <TableCell>{report.author}</TableCell>
              <TableCell>{report.findings}</TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="h-4 w-4" />
                      <span className="sr-only">Open menu</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                    <DropdownMenuItem>
                      <Eye className="mr-2 h-4 w-4" />
                      View Report
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit Report
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Download className="mr-2 h-4 w-4" />
                      Download PDF
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-destructive">
                      <Trash className="mr-2 h-4 w-4" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
