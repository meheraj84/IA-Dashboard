"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { useState } from "react"

// Mock data for audit dates
const auditDates = [
  { date: new Date(2025, 4, 5), type: "Financial", department: "Finance" },
  { date: new Date(2025, 4, 12), type: "Compliance", department: "Legal" },
  { date: new Date(2025, 4, 15), type: "IT", department: "Technology" },
  { date: new Date(2025, 4, 20), type: "Operational", department: "Operations" },
  { date: new Date(2025, 4, 25), type: "Financial", department: "Accounting" },
  { date: new Date(2025, 5, 2), type: "Compliance", department: "HR" },
  { date: new Date(2025, 5, 10), type: "IT", department: "Infrastructure" },
]

export function AuditCalendarOverview() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  // Find audits for the selected date
  const selectedDateAudits = auditDates.filter(
    (audit) =>
      date &&
      audit.date.getDate() === date.getDate() &&
      audit.date.getMonth() === date.getMonth() &&
      audit.date.getFullYear() === date.getFullYear(),
  )

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle>Audit Calendar</CardTitle>
        <CardDescription>Overview of scheduled audits</CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4 md:grid-cols-2">
        <div>
          <Calendar
            mode="single"
            selected={date}
            onSelect={setDate}
            className="rounded-md border"
            modifiers={{
              audit: auditDates.map((a) => a.date),
            }}
            modifiersStyles={{
              audit: {
                fontWeight: "bold",
                backgroundColor: "hsl(var(--primary) / 0.1)",
                color: "hsl(var(--primary))",
              },
            }}
          />
        </div>
        <div className="space-y-4">
          <div>
            <h3 className="font-medium">
              {date
                ? date.toLocaleDateString("en-US", {
                    weekday: "long",
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })
                : "Select a date"}
            </h3>
            {selectedDateAudits.length > 0 ? (
              <div className="mt-2 space-y-3">
                {selectedDateAudits.map((audit, index) => (
                  <div key={index} className="rounded-lg border p-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">{audit.department} Audit</h4>
                      <Badge variant="outline">{audit.type}</Badge>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Scheduled for {audit.date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-2 text-sm text-muted-foreground">
                {date ? "No audits scheduled for this date." : "Please select a date to view scheduled audits."}
              </p>
            )}
          </div>
          <div>
            <h3 className="font-medium">Upcoming Audits</h3>
            <div className="mt-2 space-y-2">
              {auditDates
                .filter((audit) => audit.date > new Date())
                .slice(0, 3)
                .map((audit, index) => (
                  <div key={index} className="flex items-center justify-between rounded-md border px-3 py-2">
                    <div>
                      <p className="font-medium">{audit.department}</p>
                      <p className="text-xs text-muted-foreground">{audit.type} Audit</p>
                    </div>
                    <p className="text-sm">
                      {audit.date.toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                      })}
                    </p>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
