"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

interface DashboardHeaderProps {
  heading: string
  description?: string
  children?: React.ReactNode
  showNewButton?: boolean
  newButtonLabel?: string
  onNewButtonClick?: () => void
}

export function DashboardHeader({
  heading,
  description,
  children,
  showNewButton = false,
  newButtonLabel = "New",
  onNewButtonClick,
}: DashboardHeaderProps) {
  return (
    <div className="flex items-center justify-between px-2">
      <div className="grid gap-1">
        <h1 className="text-2xl font-bold tracking-tight">{heading}</h1>
        {description && <p className="text-muted-foreground">{description}</p>}
      </div>
      <div className="flex items-center gap-2">
        {showNewButton && (
          <Button onClick={onNewButtonClick}>
            <Plus className="mr-2 h-4 w-4" />
            {newButtonLabel}
          </Button>
        )}
        {children}
      </div>
    </div>
  )
}
