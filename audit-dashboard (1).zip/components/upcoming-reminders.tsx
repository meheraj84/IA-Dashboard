import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Bell, CheckCircle } from "lucide-react"

// Mock data for upcoming reminders
const reminders = [
  {
    id: 1,
    title: "Corrective Action Follow-up",
    description: "IT Security Controls implementation verification",
    dueDate: "Tomorrow",
    priority: "high",
  },
  {
    id: 2,
    title: "Report Submission",
    description: "Q1 Financial Audit report due",
    dueDate: "In 3 days",
    priority: "medium",
  },
  {
    id: 3,
    title: "Audit Planning Meeting",
    description: "Prepare for Operations Process Review",
    dueDate: "Next week",
    priority: "low",
  },
  {
    id: 4,
    title: "Evidence Collection Deadline",
    description: "HR Policy Compliance audit documentation",
    dueDate: "In 5 days",
    priority: "medium",
  },
]

export function UpcomingReminders() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="space-y-1">
          <CardTitle>Upcoming Reminders</CardTitle>
          <CardDescription>Actions requiring your attention</CardDescription>
        </div>
        <Button variant="outline" size="icon">
          <Bell className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {reminders.map((reminder) => (
            <div key={reminder.id} className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <p className="font-medium">{reminder.title}</p>
                  <Badge
                    variant={
                      reminder.priority === "high"
                        ? "destructive"
                        : reminder.priority === "medium"
                          ? "default"
                          : "outline"
                    }
                  >
                    {reminder.priority}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{reminder.description}</p>
                <p className="text-xs font-medium">Due: {reminder.dueDate}</p>
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <CheckCircle className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
