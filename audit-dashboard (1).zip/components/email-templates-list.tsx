"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Edit, Eye, Copy, Trash } from "lucide-react"

// Mock data for email templates
const emailTemplates = [
  {
    id: 1,
    name: "Audit Notification",
    description: "Sent when a new audit is scheduled",
    category: "notification",
    lastModified: "2025-04-10",
  },
  {
    id: 2,
    name: "Finding Assignment",
    description: "Sent when a finding is assigned to someone",
    category: "assignment",
    lastModified: "2025-04-12",
  },
  {
    id: 3,
    name: "Corrective Action Due",
    description: "Reminder for upcoming corrective action deadlines",
    category: "reminder",
    lastModified: "2025-04-15",
  },
  {
    id: 4,
    name: "Report Published",
    description: "Notification when an audit report is published",
    category: "notification",
    lastModified: "2025-04-18",
  },
  {
    id: 5,
    name: "Finding Overdue",
    description: "Alert for overdue findings",
    category: "alert",
    lastModified: "2025-04-20",
  },
  {
    id: 6,
    name: "Weekly Audit Status",
    description: "Weekly summary of audit activities",
    category: "summary",
    lastModified: "2025-04-22",
  },
]

export function EmailTemplatesList() {
  const [activeTab, setActiveTab] = useState("all")

  const filteredTemplates =
    activeTab === "all" ? emailTemplates : emailTemplates.filter((template) => template.category === activeTab)

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "notification":
        return "default"
      case "reminder":
        return "secondary"
      case "alert":
        return "destructive"
      case "assignment":
        return "outline"
      case "summary":
        return "default"
      default:
        return "outline"
    }
  }

  return (
    <div className="space-y-4">
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">All Templates</TabsTrigger>
          <TabsTrigger value="notification">Notifications</TabsTrigger>
          <TabsTrigger value="reminder">Reminders</TabsTrigger>
          <TabsTrigger value="alert">Alerts</TabsTrigger>
          <TabsTrigger value="assignment">Assignments</TabsTrigger>
          <TabsTrigger value="summary">Summaries</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredTemplates.map((template) => (
          <Card key={template.id}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">{template.name}</CardTitle>
                <Badge variant={getCategoryColor(template.category) as any}>{template.category}</Badge>
              </div>
              <CardDescription>{template.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">
                Last modified: {new Date(template.lastModified).toLocaleDateString()}
              </p>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" size="sm">
                <Eye className="mr-2 h-4 w-4" />
                Preview
              </Button>
              <div className="flex gap-2">
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Copy className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                  <Trash className="h-4 w-4" />
                </Button>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}
