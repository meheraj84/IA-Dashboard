"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { MoreHorizontal, FileText, Edit, Trash, CheckCircle } from "lucide-react"

// Mock data for findings
const findings = [
  {
    id: "F-2025-001",
    title: "Inadequate Access Controls",
    department: "IT",
    area: "Security",
    severity: "Critical",
    status: "Open",
    dateIdentified: "2025-04-02",
    dueDate: "2025-05-15",
    assignedTo: "John Doe",
  },
  {
    id: "F-2025-002",
    title: "Missing Approval Documentation",
    department: "Finance",
    area: "Controls",
    severity: "High",
    status: "In Progress",
    dateIdentified: "2025-04-05",
    dueDate: "2025-05-20",
    assignedTo: "Sarah Miller",
  },
  {
    id: "F-2025-003",
    title: "Incomplete Reconciliation Process",
    department: "Finance",
    area: "Reconciliation",
    severity: "Medium",
    status: "Open",
    dateIdentified: "2025-04-08",
    dueDate: "2025-05-22",
    assignedTo: "Robert Kim",
  },
  {
    id: "F-2025-004",
    title: "Non-compliance with Data Retention Policy",
    department: "Legal",
    area: "Compliance",
    severity: "High",
    status: "Open",
    dateIdentified: "2025-04-10",
    dueDate: "2025-05-25",
    assignedTo: "Lisa Thompson",
  },
  {
    id: "F-2025-005",
    title: "Inefficient Inventory Management",
    department: "Operations",
    area: "Process",
    severity: "Medium",
    status: "In Progress",
    dateIdentified: "2025-04-12",
    dueDate: "2025-05-30",
    assignedTo: "Michael Park",
  },
  {
    id: "F-2025-006",
    title: "Outdated Business Continuity Plan",
    department: "IT",
    area: "Disaster Recovery",
    severity: "High",
    status: "Open",
    dateIdentified: "2025-04-15",
    dueDate: "2025-06-01",
    assignedTo: "John Doe",
  },
  {
    id: "F-2025-007",
    title: "Inadequate Vendor Due Diligence",
    department: "Legal",
    area: "Compliance",
    severity: "Medium",
    status: "Closed",
    dateIdentified: "2025-04-18",
    dueDate: "2025-06-05",
    assignedTo: "Sarah Miller",
  },
  {
    id: "F-2025-008",
    title: "Incomplete Employee Training Records",
    department: "HR",
    area: "Compliance",
    severity: "Low",
    status: "Closed",
    dateIdentified: "2025-04-20",
    dueDate: "2025-06-10",
    assignedTo: "Robert Kim",
  },
]

export function FindingsTable() {
  const [selectedFindings, setSelectedFindings] = useState<string[]>([])

  const toggleFindingSelection = (id: string) => {
    setSelectedFindings((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]))
  }

  const getSeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case "critical":
        return "destructive"
      case "high":
        return "destructive"
      case "medium":
        return "default"
      case "low":
        return "secondary"
      default:
        return "outline"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "open":
        return "destructive"
      case "in progress":
        return "default"
      case "closed":
        return "secondary"
      default:
        return "outline"
    }
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[100px]">ID</TableHead>
            <TableHead>Finding</TableHead>
            <TableHead>Department</TableHead>
            <TableHead>Area</TableHead>
            <TableHead>Severity</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Due Date</TableHead>
            <TableHead>Assigned To</TableHead>
            <TableHead className="w-[70px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {findings.map((finding) => (
            <TableRow key={finding.id}>
              <TableCell className="font-medium">{finding.id}</TableCell>
              <TableCell>{finding.title}</TableCell>
              <TableCell>{finding.department}</TableCell>
              <TableCell>{finding.area}</TableCell>
              <TableCell>
                <Badge variant={getSeverityColor(finding.severity) as any}>{finding.severity}</Badge>
              </TableCell>
              <TableCell>
                <Badge variant={getStatusColor(finding.status) as any}>{finding.status}</Badge>
              </TableCell>
              <TableCell>{new Date(finding.dueDate).toLocaleDateString()}</TableCell>
              <TableCell>{finding.assignedTo}</TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="h-4 w-4" />
                      <span className="sr-only">Open menu</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                    <DropdownMenuItem>
                      <FileText className="mr-2 h-4 w-4" />
                      View Details
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit Finding
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Update Status
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-destructive">
                      <Trash className="mr-2 h-4 w-4" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
