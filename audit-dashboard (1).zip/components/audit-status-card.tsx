import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowDown, ArrowRight, ArrowUp } from "lucide-react"
import { cn } from "@/lib/utils"

interface AuditStatusCardProps {
  title: string
  value: string
  description: string
  trend?: string
  trendDirection?: "up" | "down" | "neutral"
  variant?: "default" | "destructive"
}

export function AuditStatusCard({
  title,
  value,
  description,
  trend,
  trendDirection = "neutral",
  variant = "default",
}: AuditStatusCardProps) {
  return (
    <Card className={cn(variant === "destructive" && "border-destructive/50")}>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <CardDescription className="mt-1 text-xs">{description}</CardDescription>
        {trend && (
          <div
            className={cn(
              "mt-2 flex items-center text-xs font-medium",
              trendDirection === "up" && variant === "destructive" && "text-destructive",
              trendDirection === "up" && variant !== "destructive" && "text-emerald-500 dark:text-emerald-400",
              trendDirection === "down" && variant === "destructive" && "text-emerald-500 dark:text-emerald-400",
              trendDirection === "down" && variant !== "destructive" && "text-destructive",
              trendDirection === "neutral" && "text-muted-foreground",
            )}
          >
            {trendDirection === "up" && <ArrowUp className="mr-1 h-3 w-3" />}
            {trendDirection === "down" && <ArrowDown className="mr-1 h-3 w-3" />}
            {trendDirection === "neutral" && <ArrowRight className="mr-1 h-3 w-3" />}
            {trend}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
