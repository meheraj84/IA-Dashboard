"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "@/components/ui/chart"

// Mock data for findings
const departmentData = [
  { name: "Finance", value: 35, color: "#0ea5e9" },
  { name: "IT", value: 28, color: "#8b5cf6" },
  { name: "Operations", value: 42, color: "#f59e0b" },
  { name: "HR", value: 15, color: "#10b981" },
  { name: "Legal", value: 22, color: "#ef4444" },
]

const areaData = [
  { name: "Financial Controls", value: 48, color: "#0ea5e9" },
  { name: "Compliance", value: 32, color: "#8b5cf6" },
  { name: "IT Security", value: 25, color: "#f59e0b" },
  { name: "Process Efficiency", value: 22, color: "#10b981" },
  { name: "Documentation", value: 15, color: "#ef4444" },
]

export function FindingsOverview() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Findings Overview</CardTitle>
        <CardDescription>Distribution of audit findings</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="department">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="department">By Department</TabsTrigger>
            <TabsTrigger value="area">By Area</TabsTrigger>
          </TabsList>
          <TabsContent value="department" className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={departmentData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {departmentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </TabsContent>
          <TabsContent value="area" className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={areaData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {areaData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
