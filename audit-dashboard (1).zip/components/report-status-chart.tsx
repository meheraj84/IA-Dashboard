"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "@/components/ui/chart"

// Mock data for report status
const reportData = [
  {
    name: "Jan",
    published: 4,
    inProgress: 2,
    pending: 1,
  },
  {
    name: "Feb",
    published: 3,
    inProgress: 3,
    pending: 2,
  },
  {
    name: "Mar",
    published: 5,
    inProgress: 1,
    pending: 0,
  },
  {
    name: "Apr",
    published: 2,
    inProgress: 4,
    pending: 3,
  },
  {
    name: "May",
    published: 3,
    inProgress: 2,
    pending: 1,
  },
]

export function ReportStatusChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Report Status</CardTitle>
        <CardDescription>Monthly breakdown of report statuses</CardDescription>
      </CardHeader>
      <CardContent className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={reportData}
            margin={{
              top: 20,
              right: 30,
              left: 0,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="published" stackId="a" fill="#10b981" name="Published" />
            <Bar dataKey="inProgress" stackId="a" fill="#f59e0b" name="In Progress" />
            <Bar dataKey="pending" stackId="a" fill="#ef4444" name="Pending" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
