"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
} from "@/components/ui/chart"

// Mock data for trend analysis
const trendData = [
  { month: "Jan", findings: 25, resolved: 18 },
  { month: "Feb", findings: 32, resolved: 24 },
  { month: "Mar", findings: 28, resolved: 20 },
  { month: "Apr", findings: 35, resolved: 22 },
  { month: "May", findings: 30, resolved: 25 },
  { month: "Jun", findings: 22, resolved: 18 },
  { month: "Jul", findings: 18, resolved: 15 },
  { month: "Aug", findings: 24, resolved: 20 },
  { month: "Sep", findings: 30, resolved: 22 },
  { month: "Oct", findings: 35, resolved: 28 },
  { month: "Nov", findings: 40, resolved: 30 },
  { month: "Dec", findings: 32, resolved: 25 },
]

// Mock data for risk assessment
const riskData = [
  { name: "Critical", value: 15, color: "#ef4444" },
  { name: "High", value: 25, color: "#f59e0b" },
  { name: "Medium", value: 35, color: "#3b82f6" },
  { name: "Low", value: 25, color: "#10b981" },
]

// Mock data for audit efficiency
const efficiencyData = [
  { year: "2022", planned: 20, actual: 18 },
  { year: "2023", planned: 24, actual: 22 },
  { year: "2024", planned: 28, actual: 25 },
  { year: "2025", planned: 32, actual: 30 },
]

// Mock data for compliance score
const complianceData = [
  { month: "Jan", score: 75 },
  { month: "Feb", score: 78 },
  { month: "Mar", score: 80 },
  { month: "Apr", score: 82 },
  { month: "May", score: 85 },
  { month: "Jun", score: 83 },
  { month: "Jul", score: 87 },
  { month: "Aug", score: 90 },
  { month: "Sep", score: 88 },
  { month: "Oct", score: 92 },
  { month: "Nov", score: 94 },
  { month: "Dec", score: 95 },
]

export function AnalyticsDashboard() {
  return (
    <Tabs defaultValue="trends">
      <TabsList className="grid w-full grid-cols-4">
        <TabsTrigger value="trends">Trend Analysis</TabsTrigger>
        <TabsTrigger value="risk">Risk Assessment</TabsTrigger>
        <TabsTrigger value="efficiency">Audit Efficiency</TabsTrigger>
        <TabsTrigger value="compliance">Compliance Score</TabsTrigger>
      </TabsList>

      <TabsContent value="trends" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Findings Trend Analysis</CardTitle>
            <CardDescription>Monthly trend of findings identified vs. resolved</CardDescription>
          </CardHeader>
          <CardContent className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={trendData}
                margin={{
                  top: 20,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="findings"
                  stroke="#ef4444"
                  activeDot={{ r: 8 }}
                  name="Findings Identified"
                />
                <Line type="monotone" dataKey="resolved" stroke="#10b981" name="Findings Resolved" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Department Performance</CardTitle>
              <CardDescription>Findings by department over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={[
                    { month: "Q1", finance: 12, it: 18, operations: 15, hr: 8, legal: 10 },
                    { month: "Q2", finance: 15, it: 20, operations: 13, hr: 10, legal: 12 },
                    { month: "Q3", finance: 10, it: 15, operations: 18, hr: 12, legal: 8 },
                    { month: "Q4", finance: 8, it: 12, operations: 20, hr: 15, legal: 5 },
                  ]}
                  margin={{
                    top: 10,
                    right: 30,
                    left: 0,
                    bottom: 0,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="finance" stackId="1" stroke="#0ea5e9" fill="#0ea5e9" />
                  <Area type="monotone" dataKey="it" stackId="1" stroke="#8b5cf6" fill="#8b5cf6" />
                  <Area type="monotone" dataKey="operations" stackId="1" stroke="#f59e0b" fill="#f59e0b" />
                  <Area type="monotone" dataKey="hr" stackId="1" stroke="#10b981" fill="#10b981" />
                  <Area type="monotone" dataKey="legal" stackId="1" stroke="#ef4444" fill="#ef4444" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Resolution Time</CardTitle>
              <CardDescription>Average days to resolve findings by severity</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={[
                    { severity: "Critical", days: 15 },
                    { severity: "High", days: 30 },
                    { severity: "Medium", days: 45 },
                    { severity: "Low", days: 60 },
                  ]}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="severity" />
                  <YAxis label={{ value: "Days", angle: -90, position: "insideLeft" }} />
                  <Tooltip />
                  <Bar dataKey="days" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </TabsContent>

      <TabsContent value="risk" className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Risk Distribution</CardTitle>
              <CardDescription>Distribution of findings by risk level</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={riskData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={120}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {riskData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Risk Trend</CardTitle>
              <CardDescription>Risk level trends over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={[
                    { month: "Jan", critical: 5, high: 10, medium: 15, low: 8 },
                    { month: "Feb", critical: 7, high: 12, medium: 14, low: 10 },
                    { month: "Mar", critical: 6, high: 15, medium: 12, low: 12 },
                    { month: "Apr", critical: 8, high: 13, medium: 18, low: 15 },
                    { month: "May", critical: 10, high: 15, medium: 20, low: 12 },
                    { month: "Jun", critical: 8, high: 12, medium: 18, low: 10 },
                  ]}
                  margin={{
                    top: 10,
                    right: 30,
                    left: 0,
                    bottom: 0,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="critical" stroke="#ef4444" fill="#ef4444" />
                  <Area type="monotone" dataKey="high" stroke="#f59e0b" fill="#f59e0b" />
                  <Area type="monotone" dataKey="medium" stroke="#3b82f6" fill="#3b82f6" />
                  <Area type="monotone" dataKey="low" stroke="#10b981" fill="#10b981" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Risk Heatmap by Department and Area</CardTitle>
            <CardDescription>Visualization of risk concentration</CardDescription>
          </CardHeader>
          <CardContent className="h-[400px] overflow-auto">
            <div className="grid grid-cols-6 gap-2 min-w-[800px]">
              <div className="font-medium"></div>
              <div className="font-medium text-center">Financial Controls</div>
              <div className="font-medium text-center">IT Security</div>
              <div className="font-medium text-center">Compliance</div>
              <div className="font-medium text-center">Process Efficiency</div>
              <div className="font-medium text-center">Documentation</div>

              <div className="font-medium">Finance</div>
              <div className="bg-red-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                High
              </div>
              <div className="bg-yellow-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Medium
              </div>
              <div className="bg-yellow-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Medium
              </div>
              <div className="bg-green-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Low
              </div>
              <div className="bg-yellow-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Medium
              </div>

              <div className="font-medium">IT</div>
              <div className="bg-yellow-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Medium
              </div>
              <div className="bg-red-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                High
              </div>
              <div className="bg-yellow-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Medium
              </div>
              <div className="bg-yellow-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Medium
              </div>
              <div className="bg-green-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Low
              </div>

              <div className="font-medium">Operations</div>
              <div className="bg-yellow-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Medium
              </div>
              <div className="bg-green-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Low
              </div>
              <div className="bg-yellow-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Medium
              </div>
              <div className="bg-red-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                High
              </div>
              <div className="bg-yellow-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Medium
              </div>

              <div className="font-medium">HR</div>
              <div className="bg-green-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Low
              </div>
              <div className="bg-green-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Low
              </div>
              <div className="bg-red-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                High
              </div>
              <div className="bg-yellow-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Medium
              </div>
              <div className="bg-yellow-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Medium
              </div>

              <div className="font-medium">Legal</div>
              <div className="bg-yellow-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Medium
              </div>
              <div className="bg-yellow-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Medium
              </div>
              <div className="bg-red-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                High
              </div>
              <div className="bg-green-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Low
              </div>
              <div className="bg-yellow-500 h-16 rounded-md flex items-center justify-center text-white font-medium">
                Medium
              </div>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="efficiency" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Audit Efficiency</CardTitle>
            <CardDescription>Planned vs. actual audits completed</CardDescription>
          </CardHeader>
          <CardContent className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={efficiencyData}
                margin={{
                  top: 20,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="planned" fill="#3b82f6" name="Planned Audits" />
                <Bar dataKey="actual" fill="#10b981" name="Completed Audits" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Audit Duration</CardTitle>
              <CardDescription>Average days to complete audits by type</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  layout="vertical"
                  data={[
                    { type: "Financial", days: 45 },
                    { type: "Compliance", days: 30 },
                    { type: "IT", days: 40 },
                    { type: "Operational", days: 35 },
                  ]}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 80,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="type" type="category" />
                  <Tooltip />
                  <Bar dataKey="days" fill="#8b5cf6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Resource Utilization</CardTitle>
              <CardDescription>Auditor hours by audit phase</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={[
                    { phase: "Planning", hours: 120 },
                    { phase: "Fieldwork", hours: 320 },
                    { phase: "Reporting", hours: 180 },
                    { phase: "Follow-up", hours: 80 },
                  ]}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="phase" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="hours" fill="#f59e0b" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </TabsContent>

      <TabsContent value="compliance" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Compliance Score Trend</CardTitle>
            <CardDescription>Monthly compliance score trend</CardDescription>
          </CardHeader>
          <CardContent className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={complianceData}
                margin={{
                  top: 20,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis domain={[60, 100]} />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="score" stroke="#10b981" activeDot={{ r: 8 }} name="Compliance Score" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Compliance by Department</CardTitle>
              <CardDescription>Current compliance scores by department</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={[
                    { department: "Finance", score: 92 },
                    { department: "IT", score: 85 },
                    { department: "Operations", score: 88 },
                    { department: "HR", score: 95 },
                    { department: "Legal", score: 90 },
                  ]}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="department" />
                  <YAxis domain={[80, 100]} />
                  <Tooltip />
                  <Bar dataKey="score" fill="#0ea5e9" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Compliance by Regulation</CardTitle>
              <CardDescription>Compliance scores by regulatory framework</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart
                  outerRadius={90}
                  width={500}
                  height={300}
                  data={[
                    { subject: "SOX", A: 85, fullMark: 100 },
                    { subject: "GDPR", A: 90, fullMark: 100 },
                    { subject: "ISO 27001", A: 88, fullMark: 100 },
                    { subject: "HIPAA", A: 92, fullMark: 100 },
                    { subject: "PCI DSS", A: 87, fullMark: 100 },
                  ]}
                >
                  <PolarGrid />
                  <PolarAngleAxis dataKey="subject" />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} />
                  <Radar name="Compliance Score" dataKey="A" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
                  <Legend />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </TabsContent>
    </Tabs>
  )
}
