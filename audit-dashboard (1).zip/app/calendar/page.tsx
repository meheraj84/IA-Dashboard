import type { Metadata } from "next"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { AuditCalendarView } from "@/components/audit-calendar-view"

export const metadata: Metadata = {
  title: "Audit Calendar | Internal Audit Management System",
  description: "View and manage the audit schedule",
}

export default function CalendarPage() {
  return (
    <DashboardShell>
      <DashboardHeader
        heading="Audit Calendar"
        description="View and manage the audit schedule"
        showNewButton
        newButtonLabel="Schedule Audit"
      />

      <AuditCalendarView />
    </DashboardShell>
  )
}
