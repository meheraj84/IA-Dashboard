import type { Metadata } from "next"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { FindingsTable } from "@/components/findings-table"
import { FindingsFilters } from "@/components/findings-filters"

export const metadata: Metadata = {
  title: "Findings | Internal Audit Management System",
  description: "Manage and track audit findings",
}

export default function FindingsPage() {
  return (
    <DashboardShell>
      <DashboardHeader
        heading="Audit Findings"
        description="Manage and track all audit findings"
        showNewButton
        newButtonLabel="New Finding"
      />

      <FindingsFilters />
      <FindingsTable />
    </DashboardShell>
  )
}
