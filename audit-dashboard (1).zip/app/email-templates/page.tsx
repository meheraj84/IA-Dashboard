import type { Metadata } from "next"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { EmailTemplatesList } from "@/components/email-templates-list"

export const metadata: Metadata = {
  title: "Email Templates | Internal Audit Management System",
  description: "Manage email notification templates",
}

export default function EmailTemplatesPage() {
  return (
    <DashboardShell>
      <DashboardHeader
        heading="Email Templates"
        description="Manage notification email templates"
        showNewButton
        newButtonLabel="New Template"
      />

      <EmailTemplatesList />
    </DashboardShell>
  )
}
