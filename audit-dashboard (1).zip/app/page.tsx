import type { Metadata } from "next"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { AuditStatusCard } from "@/components/audit-status-card"
import { AuditCalendarOverview } from "@/components/audit-calendar-overview"
import { FindingsOverview } from "@/components/findings-overview"
import { ReportStatusChart } from "@/components/report-status-chart"
import { AuditorPerformance } from "@/components/auditor-performance"
import { RecentActivity } from "@/components/recent-activity"
import { UpcomingReminders } from "@/components/upcoming-reminders"

export const metadata: Metadata = {
  title: "Dashboard | Internal Audit Management System",
  description: "Overview of audit activities and key metrics",
}

export default function DashboardPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Dashboard" description="Overview of audit activities and key metrics" />

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <AuditStatusCard
          title="Total Audits"
          value="24"
          description="Scheduled for 2025"
          trend="+8% from last year"
          trendDirection="up"
        />
        <AuditStatusCard
          title="In Progress"
          value="7"
          description="Currently active audits"
          trend="2 due this week"
          trendDirection="neutral"
        />
        <AuditStatusCard
          title="Findings"
          value="142"
          description="Total open findings"
          trend="-12% from last quarter"
          trendDirection="down"
        />
        <AuditStatusCard
          title="Pending Actions"
          value="38"
          description="Corrective actions due"
          trend="5 overdue"
          trendDirection="up"
          variant="destructive"
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <div className="col-span-2">
          <AuditCalendarOverview />
        </div>
        <div>
          <FindingsOverview />
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <ReportStatusChart />
        <AuditorPerformance />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <RecentActivity />
        <UpcomingReminders />
      </div>
    </DashboardShell>
  )
}
