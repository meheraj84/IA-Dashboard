import type { Metadata } from "next"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { ReportsTable } from "@/components/reports-table"
import { ReportsFilters } from "@/components/reports-filters"

export const metadata: Metadata = {
  title: "Reports | Internal Audit Management System",
  description: "Manage and track audit reports",
}

export default function ReportsPage() {
  return (
    <DashboardShell>
      <DashboardHeader
        heading="Audit Reports"
        description="Manage and track all audit reports"
        showNewButton
        newButtonLabel="New Report"
      />

      <ReportsFilters />
      <ReportsTable />
    </DashboardShell>
  )
}
