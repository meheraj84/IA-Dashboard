import type { Metadata } from "next"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { ImportDataForm } from "@/components/import-data-form"

export const metadata: Metadata = {
  title: "Import Data | Internal Audit Management System",
  description: "Import data from Excel files into the audit system",
}

export default function ImportDataPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Import Data" description="Import audit data from Excel files" />

      <ImportDataForm />
    </DashboardShell>
  )
}
