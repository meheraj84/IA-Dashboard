import type { Metadata } from "next"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { AnalyticsDashboard } from "@/components/analytics-dashboard"

export const metadata: Metadata = {
  title: "Analytics | Internal Audit Management System",
  description: "Advanced analytics and insights for audit data",
}

export default function AnalyticsPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Analytics" description="Advanced analytics and insights for audit data" />

      <AnalyticsDashboard />
    </DashboardShell>
  )
}
